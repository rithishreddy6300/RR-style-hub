from datetime import datetime, timezone
from typing import Any

from sqlalchemy import DateTime, ForeignKey, Integer, JSON, String
from sqlalchemy.orm import Mapped, mapped_column

from app.models.base import Base


class Order(Base):
    __tablename__ = "orders"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id", ondelete="CASCADE"), index=True)
    status: Mapped[str] = mapped_column(String(24), default="pending", index=True)
    payment_method: Mapped[str] = mapped_column(String(32), default="credit_card")
    amount_minor_units: Mapped[int] = mapped_column("amount_cents", Integer)
    currency: Mapped[str] = mapped_column(String(3), default="inr")
    stripe_payment_intent_id: Mapped[str | None] = mapped_column(
        String(255), unique=True, index=True
    )
    shipping_address: Mapped[dict[str, str] | None] = mapped_column(JSON, nullable=True)
    items: Mapped[list[dict[str, Any]]] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), default=lambda: datetime.now(timezone.utc)
    )
