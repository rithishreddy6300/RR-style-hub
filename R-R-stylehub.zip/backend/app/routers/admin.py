import hmac
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import Settings, get_settings
from app.db import get_db
from app.models.product import Product
from app.schemas.auth import AdminLoginRequest, TokenResponse
from app.schemas.store import ProductAdminRequest, ProductResponse
from app.security import create_access_token, get_token_subject

router = APIRouter(prefix="/api/admin", tags=["admin"])
admin_scheme = HTTPBearer(auto_error=False)


def get_current_admin(
    credentials: Annotated[
        HTTPAuthorizationCredentials | None, Depends(admin_scheme)
    ],
    settings: Annotated[Settings, Depends(get_settings)],
) -> str:
    if credentials is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
            headers={"WWW-Authenticate": "Bearer"},
        )

    subject = get_token_subject(credentials.credentials, settings)
    if subject != "admin":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid admin access token",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return str(subject)


@router.post("/login", response_model=TokenResponse)
def login_admin(
    payload: AdminLoginRequest,
    settings: Annotated[Settings, Depends(get_settings)],
) -> TokenResponse:
    if not (
        hmac.compare_digest(payload.username, settings.admin_username)
        and hmac.compare_digest(
            payload.password, settings.admin_password.get_secret_value()
        )
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect admin username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    return TokenResponse(access_token=create_access_token("admin", settings))


@router.get("/products", response_model=list[ProductResponse])
def list_admin_products(
    db: Annotated[Session, Depends(get_db)],
    _: Annotated[str, Depends(get_current_admin)],
) -> list[Product]:
    return list(db.scalars(select(Product).order_by(Product.category, Product.name)).all())


@router.post("/products", response_model=ProductResponse, status_code=201)
def create_admin_product(
    payload: ProductAdminRequest,
    db: Annotated[Session, Depends(get_db)],
    _: Annotated[str, Depends(get_current_admin)],
) -> Product:
    product = Product(**payload.model_dump())
    db.add(product)
    db.commit()
    db.refresh(product)
    return product


@router.put("/products/{product_id}", response_model=ProductResponse)
def update_admin_product(
    product_id: int,
    payload: ProductAdminRequest,
    db: Annotated[Session, Depends(get_db)],
    _: Annotated[str, Depends(get_current_admin)],
) -> Product:
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    for field, value in payload.model_dump().items():
        setattr(product, field, value)
    db.commit()
    db.refresh(product)
    return product
