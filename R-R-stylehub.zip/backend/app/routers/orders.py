from typing import Annotated

import stripe
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import DatabaseSettings, get_database_settings
from app.db import get_db
from app.dependencies import get_current_user
from app.models import User
from app.models.cart import CartItem
from app.models.order import Order
from app.models.product import Product
from app.schemas.store import (
    CheckoutRequest,
    CheckoutResponse,
    OrderLineResponse,
    OrderResponse,
)

router = APIRouter(prefix="/api/orders", tags=["orders"])


def serialize_order(order: Order) -> OrderResponse:
    items = [
        {
            **item,
            "price_minor_units": item.get(
                "price_minor_units", item.get("price_cents")
            ),
            "line_total_minor_units": item.get(
                "line_total_minor_units", item.get("line_total_cents")
            ),
        }
        for item in order.items
    ]
    return OrderResponse(
        id=order.id,
        status=order.status,
        payment_method=order.payment_method,
        amount_minor_units=order.amount_minor_units,
        currency=order.currency,
        shipping_address=order.shipping_address,
        items=items,
        created_at=order.created_at.isoformat(),
    )


@router.post("/checkout", response_model=CheckoutResponse, status_code=201)
def create_checkout(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
    settings: Annotated[DatabaseSettings, Depends(get_database_settings)],
    payload: CheckoutRequest,
) -> CheckoutResponse:
    cart_rows = db.execute(
        select(CartItem, Product)
        .join(Product, Product.id == CartItem.product_id)
        .where(CartItem.user_id == user.id, Product.is_active.is_(True))
        .order_by(Product.id)
    ).all()
    if not cart_rows:
        raise HTTPException(status_code=400, detail="Your cart is empty")

    order_items = [
        {
            "product_id": product.id,
            "name": product.name,
            "image_url": product.image_url,
            "price_minor_units": product.price_minor_units,
            "quantity": cart_item.quantity,
            "line_total_minor_units": product.price_minor_units * cart_item.quantity,
        }
        for cart_item, product in cart_rows
    ]
    total_minor_units = sum(
        item["line_total_minor_units"] for item in order_items
    )
    if total_minor_units <= 0:
        raise HTTPException(status_code=400, detail="Cart total must be positive")

    order = Order(
        user_id=user.id,
        payment_method=payload.payment_method,
        amount_minor_units=total_minor_units,
        currency=settings.stripe_currency.lower(),
        shipping_address=payload.shipping_address.model_dump(),
        items=order_items,
        status="pending",
    )
    db.add(order)
    db.commit()
    db.refresh(order)

    if payload.payment_method == "cash_on_delivery":
        for cart_item, _ in cart_rows:
            db.delete(cart_item)
        db.commit()
        return CheckoutResponse(
            order=serialize_order(order),
            client_secret="",
            publishable_key=settings.stripe_publishable_key or "",
        )

    if not settings.stripe_secret_key or not settings.stripe_publishable_key:
        order.status = "failed"
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Stripe test keys are not configured",
        )

    try:
        intent = stripe.PaymentIntent.create(
            amount=total_minor_units,
            currency=order.currency,
            payment_method_types=(
                ["upi"] if payload.payment_method == "upi" else ["card"]
            ),
            metadata={"order_id": str(order.id), "user_id": str(user.id)},
            api_key=settings.stripe_secret_key.get_secret_value(),
            idempotency_key=f"stylehub-order-{order.id}",
        )
    except stripe.StripeError as error:
        order.status = "failed"
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Payment provider could not create a payment",
        ) from error

    order.stripe_payment_intent_id = intent.id
    db.commit()
    db.refresh(order)
    if not intent.client_secret:
        order.status = "failed"
        db.commit()
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail="Payment provider did not return a payment client secret",
        )
    return CheckoutResponse(
        order=serialize_order(order),
        client_secret=intent.client_secret,
        publishable_key=settings.stripe_publishable_key,
    )


@router.get("", response_model=list[OrderResponse])
def list_orders(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> list[OrderResponse]:
    orders = db.scalars(
        select(Order).where(Order.user_id == user.id).order_by(Order.created_at.desc())
    ).all()
    return [serialize_order(order) for order in orders]


@router.get("/{order_id}", response_model=OrderResponse)
def get_order(
    order_id: int,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> OrderResponse:
    order = db.scalar(
        select(Order).where(Order.id == order_id, Order.user_id == user.id)
    )
    if order is None:
        raise HTTPException(status_code=404, detail="Order not found")
    return serialize_order(order)
