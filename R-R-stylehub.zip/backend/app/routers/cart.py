from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Response, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import DatabaseSettings, get_database_settings
from app.db import get_db
from app.dependencies import get_current_user
from app.models import User
from app.models.cart import CartItem
from app.models.product import Product
from app.schemas.store import (
    CartItemRequest,
    CartQuantityRequest,
    CartResponse,
)

router = APIRouter(prefix="/api/cart", tags=["cart"])


def get_cart_response(db: Session, user_id: int) -> CartResponse:
    rows = db.execute(
        select(CartItem, Product)
        .join(Product, Product.id == CartItem.product_id)
        .where(CartItem.user_id == user_id, Product.is_active.is_(True))
        .order_by(Product.id)
    ).all()
    items = [
        {
            "product_id": product.id,
            "name": product.name,
            "image_url": product.image_url,
            "price_minor_units": product.price_minor_units,
            "quantity": cart_item.quantity,
            "line_total_minor_units": product.price_minor_units * cart_item.quantity,
        }
        for cart_item, product in rows
    ]
    return CartResponse(
        items=items,
        total_minor_units=sum(item["line_total_minor_units"] for item in items),
        currency=get_database_settings().stripe_currency.lower(),
    )


@router.get("", response_model=CartResponse)
def get_cart(
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> CartResponse:
    return get_cart_response(db, user.id)


@router.post("/items", response_model=CartResponse, status_code=201)
def add_to_cart(
    payload: CartItemRequest,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> CartResponse:
    product = db.scalar(
        select(Product).where(
            Product.id == payload.product_id, Product.is_active.is_(True)
        )
    )
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")

    item = db.scalar(
        select(CartItem).where(
            CartItem.user_id == user.id, CartItem.product_id == product.id
        )
    )
    requested_quantity = payload.quantity + (item.quantity if item else 0)
    if requested_quantity > product.stock_quantity:
        raise HTTPException(
            status_code=422,
            detail=f"Only {product.stock_quantity} units are available for {product.name}",
        )
    if item is None:
        item = CartItem(
            user_id=user.id, product_id=product.id, quantity=payload.quantity
        )
        db.add(item)
    else:
        if item.quantity + payload.quantity > 20:
            raise HTTPException(
                status_code=422, detail="A maximum of 20 of each product is allowed"
            )
        item.quantity += payload.quantity

    db.commit()
    return get_cart_response(db, user.id)


@router.put("/items/{product_id}", response_model=CartResponse)
def update_cart_quantity(
    product_id: int,
    payload: CartQuantityRequest,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> CartResponse:
    item = db.scalar(
        select(CartItem).where(
            CartItem.user_id == user.id, CartItem.product_id == product_id
        )
    )
    if item is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    product = db.get(Product, product_id)
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    if payload.quantity > product.stock_quantity:
        raise HTTPException(
            status_code=422,
            detail=f"Only {product.stock_quantity} units are available for {product.name}",
        )
    item.quantity = payload.quantity
    db.commit()
    return get_cart_response(db, user.id)


@router.delete("/items/{product_id}", status_code=status.HTTP_204_NO_CONTENT)
def remove_from_cart(
    product_id: int,
    db: Annotated[Session, Depends(get_db)],
    user: Annotated[User, Depends(get_current_user)],
) -> Response:
    item = db.scalar(
        select(CartItem).where(
            CartItem.user_id == user.id, CartItem.product_id == product_id
        )
    )
    if item is None:
        raise HTTPException(status_code=404, detail="Cart item not found")
    db.delete(item)
    db.commit()
    return Response(status_code=status.HTTP_204_NO_CONTENT)
