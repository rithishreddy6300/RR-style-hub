from typing import Annotated, Any

import stripe
from fastapi import APIRouter, Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.core.config import DatabaseSettings, get_database_settings
from app.db import get_db
from app.models.cart import CartItem
from app.models.order import Order

router = APIRouter(prefix="/api/payments", tags=["payments"])


def handle_payment_event(db: Session, event: dict[str, Any]) -> None:
    event_type = event.get("type")
    intent = event.get("data", {}).get("object", {})
    intent_id = intent.get("id")
    metadata = intent.get("metadata", {})
    order_id = metadata.get("order_id")
    if (
        not isinstance(intent_id, str)
        or not isinstance(order_id, str)
        or not order_id.isdecimal()
    ):
        return

    order = db.scalar(
        select(Order).where(
            Order.id == int(order_id), Order.stripe_payment_intent_id == intent_id
        )
    )
    if order is None or order.status in {"paid", "canceled"}:
        return

    if event_type == "payment_intent.succeeded":
        if (
            intent.get("amount_received") != order.amount_minor_units
            or intent.get("currency") != order.currency
        ):
            order.status = "failed"
            db.commit()
            return
        order.status = "paid"
        for snapshot in order.items:
            cart_item = db.scalar(
                select(CartItem).where(
                    CartItem.user_id == order.user_id,
                    CartItem.product_id == snapshot["product_id"],
                )
            )
            if cart_item is None:
                continue
            cart_item.quantity -= snapshot["quantity"]
            if cart_item.quantity <= 0:
                db.delete(cart_item)
    elif event_type in {
        "payment_intent.payment_failed",
        "payment_intent.canceled",
    }:
        order.status = (
            "canceled"
            if event_type == "payment_intent.canceled"
            else "failed"
        )
    else:
        return
    db.commit()


@router.post("/webhook")
async def stripe_webhook(
    request: Request,
    db: Annotated[Session, Depends(get_db)],
    settings: Annotated[DatabaseSettings, Depends(get_database_settings)],
) -> dict[str, bool]:
    if not settings.stripe_webhook_secret:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Stripe webhook secret is not configured",
        )
    payload = await request.body()
    signature = request.headers.get("stripe-signature", "")
    try:
        event = stripe.Webhook.construct_event(
            payload,
            signature,
            settings.stripe_webhook_secret.get_secret_value(),
        )
    except (stripe.SignatureVerificationError, ValueError) as error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid Stripe webhook signature or payload",
        ) from error

    handle_payment_event(db, event)
    return {"received": True}
