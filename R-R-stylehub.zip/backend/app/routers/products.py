from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.db import get_db
from app.models.product import Product
from app.schemas.store import ProductResponse

router = APIRouter(prefix="/api/products", tags=["products"])


@router.get("", response_model=list[ProductResponse])
def list_products(db: Annotated[Session, Depends(get_db)]) -> list[Product]:
    return list(
        db.scalars(
            select(Product)
            .where(Product.is_active.is_(True))
            .order_by(Product.category, Product.name)
        ).all()
    )


@router.get("/{product_id}", response_model=ProductResponse)
def get_product(
    product_id: int, db: Annotated[Session, Depends(get_db)]
) -> Product:
    product = db.scalar(
        select(Product).where(
            Product.id == product_id, Product.is_active.is_(True)
        )
    )
    if product is None:
        raise HTTPException(status_code=404, detail="Product not found")
    return product
