from typing import Literal

from pydantic import BaseModel, Field, HttpUrl, field_validator

PaymentMethod = Literal[
    "cash_on_delivery",
    "upi",
    "debit_card",
    "credit_card",
]


class ProductResponse(BaseModel):
    id: int
    name: str
    description: str
    category: str
    price_minor_units: int
    stock_quantity: int = 0
    image_url: HttpUrl

    model_config = {"from_attributes": True}


class ProductAdminRequest(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    description: str = Field(min_length=1)
    category: str = Field(min_length=1, max_length=60)
    price_minor_units: int = Field(gt=0)
    stock_quantity: int = Field(ge=0, le=5000)
    image_url: str = Field(min_length=1, max_length=500)


class CartItemRequest(BaseModel):
    product_id: int = Field(gt=0)
    quantity: int = Field(default=1, ge=1, le=20)


class CartQuantityRequest(BaseModel):
    quantity: int = Field(ge=1, le=20)


class CartLineResponse(BaseModel):
    product_id: int
    name: str
    image_url: HttpUrl
    price_minor_units: int
    quantity: int
    line_total_minor_units: int


class CartResponse(BaseModel):
    items: list[CartLineResponse]
    total_minor_units: int
    currency: str


class OrderLineResponse(BaseModel):
    product_id: int
    name: str
    image_url: str
    price_minor_units: int
    quantity: int
    line_total_minor_units: int


class ShippingAddress(BaseModel):
    model_config = {"str_strip_whitespace": True}

    full_name: str = Field(min_length=1, max_length=120)
    phone: str = Field(min_length=7, max_length=20)
    address_line1: str = Field(min_length=3, max_length=200)
    address_line2: str = Field(default="", max_length=200)
    city: str = Field(min_length=2, max_length=100)
    state: str = Field(min_length=2, max_length=100)
    postal_code: str = Field(min_length=3, max_length=12)

    @field_validator("phone")
    @classmethod
    def phone_has_valid_digit_count(cls, phone: str) -> str:
        digit_count = sum(character.isdigit() for character in phone)
        if not 7 <= digit_count <= 15:
            raise ValueError("Phone number must contain 7 to 15 digits")
        return phone


class OrderResponse(BaseModel):
    id: int
    status: Literal["pending", "paid", "failed", "canceled"]
    payment_method: PaymentMethod
    amount_minor_units: int
    currency: str
    shipping_address: ShippingAddress | None = None
    items: list[OrderLineResponse]
    created_at: str


class CheckoutRequest(BaseModel):
    payment_method: PaymentMethod = "credit_card"
    shipping_address: ShippingAddress


class CheckoutResponse(BaseModel):
    order: OrderResponse
    client_secret: str
    publishable_key: str
