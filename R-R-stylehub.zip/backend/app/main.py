from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy import create_engine, func, inspect, select, text
from sqlalchemy.engine import Engine
from sqlalchemy.orm import sessionmaker

from app.core.config import get_database_settings
from app.models import Base, Product
from app.routers.admin import router as admin_router
from app.routers.auth import router as auth_router
from app.routers.cart import router as cart_router
from app.routers.orders import router as orders_router
from app.routers.payments import router as payments_router
from app.routers.products import router as products_router

DEMO_PRODUCTS = [
    {
        "name": "Everyday Linen Shirt",
        "description": "A relaxed-fit linen blend for warm days and easy layering.",
        "category": "Clothing",
        "price_minor_units": 5900,
        "stock_quantity": 18,
        "image_url": "https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "The Soft Knit",
        "description": "A soft, lightweight knit with a timeless crew neckline.",
        "category": "Clothing",
        "price_minor_units": 7400,
        "stock_quantity": 22,
        "image_url": "https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "Weekend Tote",
        "description": "A roomy everyday tote for market mornings and city afternoons.",
        "category": "Accessories",
        "price_minor_units": 4200,
        "stock_quantity": 24,
        "image_url": "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "Classic Low Sneaker",
        "description": "An understated low-top sneaker built for all-day comfort.",
        "category": "Shoes",
        "price_minor_units": 8900,
        "stock_quantity": 12,
        "image_url": "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "Everyday Denim",
        "description": "Easy straight-leg denim made to go with just about everything.",
        "category": "Clothing",
        "price_minor_units": 8200,
        "stock_quantity": 15,
        "image_url": "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "Weekend Sunglasses",
        "description": "A modern acetate frame with a little vintage character.",
        "category": "Accessories",
        "price_minor_units": 3600,
        "stock_quantity": 30,
        "image_url": "https://images.unsplash.com/photo-1511499767150-a48a237f0083?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "The Essential Jacket",
        "description": "A versatile layer with a clean shape and thoughtful details.",
        "category": "Clothing",
        "price_minor_units": 12800,
        "stock_quantity": 10,
        "image_url": "https://images.unsplash.com/photo-1548126032-079a0fb0099d?auto=format&fit=crop&w=900&q=85",
    },
    {
        "name": "Canvas Market Bag",
        "description": "A durable carryall for errands, books, and everything between.",
        "category": "Accessories",
        "price_minor_units": 2900,
        "stock_quantity": 26,
        "image_url": "https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=900&q=85",
    },
]


def create_app(database_url: str | None = None) -> FastAPI:
    database_settings = get_database_settings()
    resolved_database_url = database_url or database_settings.database_url
    connect_args = (
        {"check_same_thread": False}
        if resolved_database_url.startswith("sqlite")
        else {}
    )
    engine: Engine = create_engine(resolved_database_url, connect_args=connect_args)
    session_factory = sessionmaker(bind=engine, expire_on_commit=False)

    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        Base.metadata.create_all(bind=engine)
        order_columns = {
            column["name"] for column in inspect(engine).get_columns("orders")
        }
        if "shipping_address" not in order_columns:
            with engine.begin() as connection:
                connection.execute(
                    text("ALTER TABLE orders ADD COLUMN shipping_address JSON")
                )
        with session_factory() as session:
            product_count = session.scalar(select(func.count()).select_from(Product))
            if product_count == 0:
                session.add_all(Product(**product) for product in DEMO_PRODUCTS)
                session.commit()
        yield
        engine.dispose()

    app = FastAPI(title="StyleHub API", version="0.1.0", lifespan=lifespan)
    app.state.session_factory = session_factory
    app.add_middleware(
        CORSMiddleware,
        allow_origins=database_settings.cors_origins,
        allow_credentials=False,
        allow_methods=["GET", "POST", "PUT", "DELETE"],
        allow_headers=["Authorization", "Content-Type"],
    )
    app.include_router(admin_router)
    app.include_router(auth_router)
    app.include_router(products_router)
    app.include_router(cart_router)
    app.include_router(orders_router)
    app.include_router(payments_router)

    @app.get("/health", tags=["health"])
    def health_check() -> dict[str, str]:
        return {"status": "ok"}

    return app


app = create_app()
