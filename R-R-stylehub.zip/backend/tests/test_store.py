import hashlib
import hmac
import json
import time
from types import SimpleNamespace

import stripe
from fastapi.testclient import TestClient

from app.core.config import DatabaseSettings, Settings, get_database_settings, get_settings
from app.main import create_app


def checkout_payload(payment_method: str = "credit_card") -> dict[str, object]:
    return {
        "payment_method": payment_method,
        "shipping_address": {
            "full_name": "Taylor Customer",
            "phone": "+919876543210",
            "address_line1": "12 Market Road",
            "address_line2": "Near City Park",
            "city": "Hyderabad",
            "state": "Telangana",
            "postal_code": "500001",
        },
    }


def make_client(tmp_path) -> TestClient:
    app = create_app(f"sqlite:///{tmp_path / 'store.db'}")
    app.dependency_overrides[get_settings] = lambda: Settings(
        jwt_secret_key="test-secret-key-that-is-at-least-32-characters"
    )
    app.dependency_overrides[get_database_settings] = lambda: DatabaseSettings(
        stripe_secret_key="sk_test_fake",
        stripe_publishable_key="pk_test_fake",
        stripe_webhook_secret="whsec_test_fake",
    )
    return TestClient(app)


def register_and_login(client: TestClient, email: str) -> str:
    response = client.post(
        "/api/auth/register",
        json={"email": email, "password": "correct-horse-1"},
    )
    assert response.status_code == 201
    login = client.post(
        "/api/auth/login",
        json={"email": email, "password": "correct-horse-1"},
    )
    assert login.status_code == 200
    return login.json()["access_token"]


def post_signed_webhook(client: TestClient, event: dict[str, object]):
    payload = json.dumps(event, separators=(",", ":"))
    timestamp = str(int(time.time()))
    signature = hmac.new(
        b"whsec_test_fake",
        f"{timestamp}.{payload}".encode(),
        hashlib.sha256,
    ).hexdigest()
    return client.post(
        "/api/payments/webhook",
        content=payload,
        headers={"stripe-signature": f"t={timestamp},v1={signature}"},
    )


def test_catalog_and_user_scoped_cart(tmp_path) -> None:
    with make_client(tmp_path) as client:
        first_token = register_and_login(client, "first@example.com")
        second_token = register_and_login(client, "second@example.com")
        first_headers = {"Authorization": f"Bearer {first_token}"}
        second_headers = {"Authorization": f"Bearer {second_token}"}

        products = client.get("/api/products")
        assert products.status_code == 200
        assert len(products.json()) == 8
        product = products.json()[0]
        assert client.get(f"/api/products/{product['id']}").json()["id"] == product["id"]
        assert client.get("/api/products/9999").status_code == 404
        assert client.get("/api/cart").status_code == 401

        added = client.post(
            "/api/cart/items",
            headers=first_headers,
            json={"product_id": product["id"], "quantity": 2},
        )
        assert added.status_code == 201
        assert added.json()["items"][0]["quantity"] == 2
        assert added.json()["total_minor_units"] == product["price_minor_units"] * 2
        assert added.json()["currency"] == "inr"

        second_cart = client.get("/api/cart", headers=second_headers)
        assert second_cart.status_code == 200
        assert second_cart.json()["items"] == []

        updated = client.put(
            f"/api/cart/items/{product['id']}",
            headers=first_headers,
            json={"quantity": 3},
        )
        assert updated.json()["items"][0]["quantity"] == 3

        assert client.delete(
            f"/api/cart/items/{product['id']}", headers=first_headers
        ).status_code == 204
        assert client.get("/api/cart", headers=first_headers).json()["items"] == []
        assert client.post(
            "/api/cart/items",
            headers=first_headers,
            json={"product_id": 9999, "quantity": 1},
        ).status_code == 404


def test_stripe_checkout_uses_server_total_and_webhook_completes_order(
    tmp_path, monkeypatch
) -> None:
    captured: dict[str, object] = {}

    def create_intent(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(id="pi_stylehub_test", client_secret="pi_secret_test")

    monkeypatch.setattr(stripe.PaymentIntent, "create", create_intent)

    with make_client(tmp_path) as client:
        token = register_and_login(client, "buyer@example.com")
        headers = {"Authorization": f"Bearer {token}"}
        product = client.get("/api/products").json()[0]
        client.post(
            "/api/cart/items",
            headers=headers,
            json={"product_id": product["id"], "quantity": 2},
        )

        checkout = client.post(
            "/api/orders/checkout",
            headers=headers,
            json=checkout_payload(),
        )
        assert checkout.status_code == 201
        result = checkout.json()
        expected_amount = product["price_minor_units"] * 2
        assert result["order"]["amount_minor_units"] == expected_amount
        assert result["order"]["status"] == "pending"
        assert result["client_secret"] == "pi_secret_test"
        assert captured["amount"] == expected_amount
        assert captured["currency"] == "inr"
        assert captured["idempotency_key"] == f"stylehub-order-{result['order']['id']}"

        webhook_event = {
            "id": "evt_stylehub_test",
            "type": "payment_intent.succeeded",
            "data": {
                "object": {
                    "id": "pi_stylehub_test",
                    "amount_received": expected_amount,
                    "currency": "inr",
                    "metadata": {"order_id": str(result["order"]["id"])},
                }
            },
        }
        payload = json.dumps(webhook_event, separators=(",", ":"))
        timestamp = str(int(time.time()))
        invalid_webhook = client.post(
            "/api/payments/webhook",
            content=payload,
            headers={"stripe-signature": f"t={timestamp},v1=invalid"},
        )
        assert invalid_webhook.status_code == 400
        webhook = post_signed_webhook(client, webhook_event)
        assert webhook.status_code == 200
        assert webhook.json() == {"received": True}

        order_response = client.get(
            f"/api/orders/{result['order']['id']}", headers=headers
        )
        assert order_response.status_code == 200
        assert order_response.json()["status"] == "paid"
        assert order_response.json()["shipping_address"]["full_name"] == "Taylor Customer"
        assert order_response.json()["shipping_address"]["postal_code"] == "500001"
        assert client.get("/api/orders", headers=headers).json()[0]["status"] == "paid"
        assert client.get(
            f"/api/orders/{result['order']['id']}",
            headers={"Authorization": f"Bearer {register_and_login(client, 'intruder@example.com')}"},
        ).status_code == 404
        assert client.get("/api/cart", headers=headers).json()["items"] == []


def test_failed_payment_webhook_keeps_cart_for_retry(tmp_path, monkeypatch) -> None:
    monkeypatch.setattr(
        stripe.PaymentIntent,
        "create",
        lambda **kwargs: SimpleNamespace(
            id="pi_stylehub_failed", client_secret="pi_secret_failed"
        ),
    )
    with make_client(tmp_path) as client:
        token = register_and_login(client, "retry@example.com")
        headers = {"Authorization": f"Bearer {token}"}
        product = client.get("/api/products").json()[0]
        client.post(
            "/api/cart/items",
            headers=headers,
            json={"product_id": product["id"], "quantity": 1},
        )
        checkout = client.post(
            "/api/orders/checkout",
            headers=headers,
            json=checkout_payload(),
        )
        assert checkout.status_code == 201
        order_id = checkout.json()["order"]["id"]

        webhook = post_signed_webhook(
            client,
            {
                "id": "evt_stylehub_failed",
                "type": "payment_intent.payment_failed",
                "data": {
                    "object": {
                        "id": "pi_stylehub_failed",
                        "metadata": {"order_id": str(order_id)},
                    }
                },
            },
        )
        assert webhook.status_code == 200
        order = client.get(f"/api/orders/{order_id}", headers=headers)
        assert order.json()["status"] == "failed"
        assert len(client.get("/api/cart", headers=headers).json()["items"]) == 1


def test_checkout_refuses_empty_cart_and_unconfigured_stripe(tmp_path) -> None:
    with make_client(tmp_path) as client:
        token = register_and_login(client, "empty@example.com")
        headers = {"Authorization": f"Bearer {token}"}
        assert client.post(
            "/api/orders/checkout", headers=headers, json=checkout_payload()
        ).status_code == 400

        client.app.dependency_overrides[get_database_settings] = lambda: DatabaseSettings()
        product = client.get("/api/products").json()[0]
        client.post(
            "/api/cart/items",
            headers=headers,
            json={"product_id": product["id"], "quantity": 1},
        )
        assert client.post(
            "/api/orders/checkout", headers=headers, json=checkout_payload()
        ).status_code == 503


def test_cash_on_delivery_places_order_and_clears_cart(tmp_path) -> None:
    with make_client(tmp_path) as client:
        token = register_and_login(client, "delivery@example.com")
        headers = {"Authorization": f"Bearer {token}"}
        product = client.get("/api/products").json()[0]
        client.post(
            "/api/cart/items",
            headers=headers,
            json={"product_id": product["id"], "quantity": 2},
        )

        response = client.post(
            "/api/orders/checkout",
            headers=headers,
            json=checkout_payload("cash_on_delivery"),
        )

        assert response.status_code == 201
        assert response.json()["order"]["payment_method"] == "cash_on_delivery"
        assert response.json()["order"]["status"] == "pending"
        assert response.json()["order"]["shipping_address"]["city"] == "Hyderabad"
        assert response.json()["client_secret"] == ""
        assert client.get("/api/cart", headers=headers).json()["items"] == []


def test_upi_checkout_creates_upi_payment_intent(tmp_path, monkeypatch) -> None:
    captured: dict[str, object] = {}

    def create_intent(**kwargs):
        captured.update(kwargs)
        return SimpleNamespace(id="pi_upi_test", client_secret="pi_secret_upi")

    monkeypatch.setattr(stripe.PaymentIntent, "create", create_intent)

    with make_client(tmp_path) as client:
        token = register_and_login(client, "upi@example.com")
        headers = {"Authorization": f"Bearer {token}"}
        product = client.get("/api/products").json()[0]
        client.post(
            "/api/cart/items",
            headers=headers,
            json={"product_id": product["id"], "quantity": 1},
        )

        response = client.post(
            "/api/orders/checkout",
            headers=headers,
            json=checkout_payload("upi"),
        )

        assert response.status_code == 201
        assert response.json()["order"]["payment_method"] == "upi"
        assert captured["payment_method_types"] == ["upi"]


def test_admin_can_add_and_update_customer_catalog_products(tmp_path) -> None:
    with make_client(tmp_path) as client:
        assert client.get("/api/admin/products").status_code == 401
        login = client.post(
            "/api/admin/login",
            json={"username": "REDDY", "password": "6300648854"},
        )
        assert login.status_code == 200
        headers = {"Authorization": f"Bearer {login.json()['access_token']}"}
        product_data = {
            "name": "Admin test item",
            "description": "Product created by the store admin.",
            "category": "Accessories",
            "price_minor_units": 1250,
            "stock_quantity": 7,
            "image_url": "https://example.com/product.jpg",
        }

        created = client.post(
            "/api/admin/products", headers=headers, json=product_data
        )
        assert created.status_code == 201
        product_id = created.json()["id"]
        assert any(
            product["id"] == product_id
            for product in client.get("/api/products").json()
        )

        updated_data = {**product_data, "price_minor_units": 1500, "stock_quantity": 9}
        updated = client.put(
            f"/api/admin/products/{product_id}",
            headers=headers,
            json=updated_data,
        )
        assert updated.status_code == 200
        assert updated.json()["price_minor_units"] == 1500
        assert updated.json()["stock_quantity"] == 9


def test_admin_login_rejects_wrong_credentials(tmp_path) -> None:
    with make_client(tmp_path) as client:
        response = client.post(
            "/api/admin/login",
            json={"username": "REDDY", "password": "not-the-password"},
        )
        assert response.status_code == 401
