from fastapi.testclient import TestClient

from app.core.config import Settings, get_settings
from app.main import create_app


def test_registration_login_and_protected_profile(tmp_path) -> None:
    app = create_app(f"sqlite:///{tmp_path / 'test.db'}")
    app.dependency_overrides[get_settings] = lambda: Settings(
        jwt_secret_key="test-secret-key-that-is-at-least-32-characters"
    )

    with TestClient(app) as client:
        registered = client.post(
            "/api/auth/register",
            json={"email": "Shopper@Example.com", "password": "correct-horse-1"},
        )
        assert registered.status_code == 201
        assert registered.json()["email"] == "shopper@example.com"
        assert "hashed_password" not in registered.json()

        duplicate = client.post(
            "/api/auth/register",
            json={"email": "shopper@example.com", "password": "another-password"},
        )
        assert duplicate.status_code == 409

        login = client.post(
            "/api/auth/login",
            json={"email": "SHOPPER@example.com", "password": "correct-horse-1"},
        )
        assert login.status_code == 200
        token = login.json()["access_token"]
        assert login.json()["token_type"] == "bearer"

        profile = client.get(
            "/api/auth/me", headers={"Authorization": f"Bearer {token}"}
        )
        assert profile.status_code == 200
        assert profile.json() == {"id": 1, "email": "shopper@example.com"}

        unauthorized = client.get("/api/auth/me")
        assert unauthorized.status_code == 401

        wrong_password = client.post(
            "/api/auth/login",
            json={"email": "shopper@example.com", "password": "wrong-password"},
        )
        assert wrong_password.status_code == 401


def test_registration_validates_email_and_bcrypt_password_length(tmp_path) -> None:
    app = create_app(f"sqlite:///{tmp_path / 'validation.db'}")
    app.dependency_overrides[get_settings] = lambda: Settings(
        jwt_secret_key="test-secret-key-that-is-at-least-32-characters"
    )

    with TestClient(app) as client:
        invalid_email = client.post(
            "/api/auth/register",
            json={"email": "not-an-email", "password": "correct-horse-1"},
        )
        assert invalid_email.status_code == 422

        too_long_password = client.post(
            "/api/auth/register",
            json={"email": "shopper@example.com", "password": "é" * 37},
        )
        assert too_long_password.status_code == 422

        oversized_login_password = client.post(
            "/api/auth/login",
            json={"email": "shopper@example.com", "password": "é" * 37},
        )
        assert oversized_login_password.status_code == 422
