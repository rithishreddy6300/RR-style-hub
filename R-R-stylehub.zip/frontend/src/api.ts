export type User = {
  id: number
  email: string
}

export type Product = {
  id: number
  name: string
  description: string
  category: string
  price_minor_units: number
  stock_quantity: number
  image_url: string
}

export type AdminProduct = Product

export type PaymentMethod =
  | 'cash_on_delivery'
  | 'upi'
  | 'debit_card'
  | 'credit_card'

export type ShippingAddress = {
  full_name: string
  phone: string
  address_line1: string
  address_line2: string
  city: string
  state: string
  postal_code: string
}

export type CartLine = {
  product_id: number
  name: string
  image_url: string
  price_minor_units: number
  quantity: number
  line_total_minor_units: number
}

export type Cart = {
  items: CartLine[]
  total_minor_units: number
  currency: string
}

export type OrderLine = CartLine

export type Order = {
  id: number
  status: 'pending' | 'paid' | 'failed' | 'canceled'
  payment_method: PaymentMethod
  amount_minor_units: number
  currency: string
  shipping_address: ShippingAddress | null
  items: OrderLine[]
  created_at: string
}

export type Checkout = {
  order: Order
  client_secret: string
  publishable_key: string
}

export type AdminProductInput = Omit<Product, 'id'>

type ApiError = {
  detail?: string | { msg?: string }[]
}

const API_URL = import.meta.env.VITE_API_URL ?? 'http://localhost:8000'

export async function apiRequest<T>(
  path: string,
  token?: string,
  options: RequestInit = {},
): Promise<T> {
  const headers = new Headers(options.headers)
  if (options.body && !headers.has('Content-Type')) {
    headers.set('Content-Type', 'application/json')
  }
  if (token) headers.set('Authorization', `Bearer ${token}`)

  const response = await fetch(`${API_URL}${path}`, { ...options, headers })
  if (response.status === 204) return undefined as T

  const result: unknown = await response.json()
  if (!response.ok) {
    const detail = (result as ApiError).detail
    const message = Array.isArray(detail)
      ? detail.map((issue) => issue.msg ?? 'Invalid input').join(', ')
      : detail
    throw new Error(message ?? 'The request could not be completed.')
  }
  return result as T
}

export function formatPrice(minorUnits: number, currency = 'inr'): string {
  return new Intl.NumberFormat(undefined, {
    style: 'currency',
    currency: currency.toUpperCase(),
  }).format(minorUnits / 100)
}
