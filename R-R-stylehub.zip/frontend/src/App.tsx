import { useEffect, useState, type FormEvent } from 'react'
import CheckoutPanel from './CheckoutPanel'
import {
  apiRequest,
  formatPrice,
  type Cart,
  type Checkout,
  type Order,
  type PaymentMethod,
  type Product,
  type ShippingAddress,
  type User,
} from './api'
import './App.css'

type TokenResponse = {
  access_token: string
  token_type: string
}

type View = 'shop' | 'cart' | 'checkout' | 'orders'

const emptyShippingAddress: ShippingAddress = {
  full_name: '',
  phone: '',
  address_line1: '',
  address_line2: '',
  city: '',
  state: '',
  postal_code: '',
}

function App() {
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState<string | null>(
    () => sessionStorage.getItem('stylehub-token'),
  )
  const [user, setUser] = useState<User | null>(null)
  const [products, setProducts] = useState<Product[]>([])
  const [cart, setCart] = useState<Cart | null>(null)
  const [orders, setOrders] = useState<Order[]>([])
  const [checkout, setCheckout] = useState<Checkout | null>(null)
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('cash_on_delivery')
  const [shippingAddress, setShippingAddress] = useState<ShippingAddress>(emptyShippingAddress)
  const [view, setView] = useState<View>(
    () => new URLSearchParams(window.location.search).has('payment') ? 'orders' : 'shop',
  )
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isRestoring, setIsRestoring] = useState(Boolean(token))

  async function reconcileReturnedPayment(
    orderHistory: Order[],
    accessToken: string,
    isActive: () => boolean,
  ) {
    if (new URLSearchParams(window.location.search).get('payment') !== 'complete') {
      return
    }

    const pendingOrder = orderHistory.find((order) => order.status === 'pending')
    if (!pendingOrder || !isActive()) return

    setNotice('Payment submitted. Confirming your order…')
    for (let attempt = 0; attempt < 10; attempt += 1) {
      const order = await apiRequest<Order>(`/api/orders/${pendingOrder.id}`, accessToken)
      if (!isActive()) return
      setOrders((current) => [
        order,
        ...current.filter((existing) => existing.id !== order.id),
      ])
      if (order.status === 'paid') {
        setNotice('Payment successful — your order is confirmed.')
        const updatedCart = await apiRequest<Cart>('/api/cart', accessToken)
        if (!isActive()) return
        setCart(updatedCart)
        return
      }
      if (order.status === 'failed' || order.status === 'canceled') {
        setNotice(`Payment ${order.status}. You can try checkout again from your bag.`)
        return
      }
      await new Promise((resolve) => window.setTimeout(resolve, 1000))
    }
    if (isActive()) {
      setNotice('Payment submitted. Your order status will update when Stripe confirms it.')
    }
  }

  useEffect(() => {
    let active = true
    apiRequest<Product[]>('/api/products')
      .then((result) => {
        if (active) setProducts(result)
      })
      .catch((requestError: unknown) => {
        if (active) setError(requestError instanceof Error ? requestError.message : 'Products could not be loaded.')
      })
    return () => {
      active = false
    }
  }, [])

  useEffect(() => {
    if (!token) {
      return
    }

    let active = true
    Promise.all([
      apiRequest<User>('/api/auth/me', token),
      apiRequest<Cart>('/api/cart', token),
      apiRequest<Order[]>('/api/orders', token),
    ])
      .then(([profile, currentCart, orderHistory]) => {
        if (!active) return
        setUser(profile)
        setCart(currentCart)
        setOrders(orderHistory)
        void reconcileReturnedPayment(orderHistory, token, () => active).catch(
          (requestError: unknown) => {
            if (active) {
              setError(
                requestError instanceof Error
                  ? requestError.message
                  : 'Your payment status could not be refreshed.',
              )
            }
          },
        )
      })
      .catch((requestError: unknown) => {
        if (!active) return
        sessionStorage.removeItem('stylehub-token')
        setToken(null)
        setUser(null)
        setError(requestError instanceof Error ? requestError.message : 'Your session could not be restored.')
      })
      .finally(() => {
        if (active) setIsRestoring(false)
      })
    return () => {
      active = false
    }
  }, [token])

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setIsLoading(true)
    try {
      if (mode === 'register') {
        await apiRequest<User>('/api/auth/register', undefined, {
          method: 'POST',
          body: JSON.stringify({ email, password }),
        })
      }
      const auth = await apiRequest<TokenResponse>('/api/auth/login', undefined, {
        method: 'POST',
        body: JSON.stringify({ email, password }),
      })
      const [profile, currentCart, orderHistory] = await Promise.all([
        apiRequest<User>('/api/auth/me', auth.access_token),
        apiRequest<Cart>('/api/cart', auth.access_token),
        apiRequest<Order[]>('/api/orders', auth.access_token),
      ])
      sessionStorage.setItem('stylehub-token', auth.access_token)
      setToken(auth.access_token)
      setUser(profile)
      setCart(currentCart)
      setOrders(orderHistory)
      setPassword('')
      setView(new URLSearchParams(window.location.search).has('payment') ? 'orders' : 'shop')
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? requestError.message
          : 'Something went wrong. Please try again.',
      )
    } finally {
      setIsLoading(false)
    }
  }

  async function refreshCart() {
    if (!token) return
    setCart(await apiRequest<Cart>('/api/cart', token))
  }

  async function refreshOrders() {
    if (!token) return
    setOrders(await apiRequest<Order[]>('/api/orders', token))
  }

  async function addToCart(productId: number) {
    if (!token) return
    setNotice('')
    try {
      const updated = await apiRequest<Cart>('/api/cart/items', token, {
        method: 'POST',
        body: JSON.stringify({ product_id: productId, quantity: 1 }),
      })
      setCart(updated)
      setNotice('Added to your bag.')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Could not update your bag.')
    }
  }

  async function updateQuantity(productId: number, quantity: number) {
    if (!token) return
    try {
      const updated = await apiRequest<Cart>(`/api/cart/items/${productId}`, token, {
        method: 'PUT',
        body: JSON.stringify({ quantity }),
      })
      setCart(updated)
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Could not update your bag.')
    }
  }

  async function removeFromCart(productId: number) {
    if (!token) return
    try {
      await apiRequest<void>(`/api/cart/items/${productId}`, token, { method: 'DELETE' })
      await refreshCart()
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Could not remove that item.')
    }
  }

  async function beginCheckout() {
    if (!token) return
    setError('')
    setIsLoading(true)
    try {
      const payment = await apiRequest<Checkout>('/api/orders/checkout', token, {
        method: 'POST',
        body: JSON.stringify({
          payment_method: paymentMethod,
          shipping_address: shippingAddress,
        }),
      })
      if (paymentMethod === 'cash_on_delivery') {
        setOrders((current) => [payment.order, ...current])
        setCart({
          items: [],
          total_minor_units: 0,
          currency: payment.order.currency,
        })
        setView('orders')
        setNotice(`Order #${payment.order.id} placed. Pay when it arrives.`)
        return
      }
      setCheckout(payment)
      setView('checkout')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Checkout could not be started.')
    } finally {
      setIsLoading(false)
    }
  }

  async function finishCheckout() {
    if (!token || !checkout) return
    setView('orders')
    setCheckout(null)
    setNotice('Payment received. Confirming your order…')
    const orderId = checkout.order.id
    try {
      for (let attempt = 0; attempt < 10; attempt += 1) {
        const order = await apiRequest<Order>(`/api/orders/${orderId}`, token)
        setOrders((current) => [
          order,
          ...current.filter((existing) => existing.id !== order.id),
        ])
        if (order.status === 'paid') {
          setNotice('Payment successful — your order is confirmed.')
          await refreshCart()
          return
        }
        if (order.status === 'failed' || order.status === 'canceled') {
          setNotice(`Payment ${order.status}. You can try checkout again from your bag.`)
          return
        }
        await new Promise((resolve) => window.setTimeout(resolve, 1000))
      }
      setNotice('Payment submitted. Your order status will update when Stripe confirms it.')
      await refreshOrders()
    } catch (requestError) {
      setError(
        requestError instanceof Error
          ? `Payment was submitted, but order status could not be refreshed: ${requestError.message}`
          : 'Payment was submitted, but order status could not be refreshed.',
      )
    }
  }

  function signOut() {
    sessionStorage.removeItem('stylehub-token')
    setToken(null)
    setUser(null)
    setCart(null)
    setOrders([])
    setCheckout(null)
    setNotice('')
    setView('shop')
  }

  if (isRestoring) {
    return <main className="page-shell loading-state">Opening your StyleHub…</main>
  }

  if (!user || !token) {
    return (
      <main className="page-shell">
        <header className="topbar">
          <a className="wordmark" href="/">R&amp;R stylehub</a>
          <div className="admin-top-actions">
            <span className="topbar-note">A little more you.</span>
            <a className="text-button admin-link" href="/admin">Admin</a>
          </div>
        </header>
        <section className="auth-layout">
          <div className="editorial">
            <p className="eyebrow">THE NEW SEASON EDIT</p>
            <h1>Find your<br />everyday <em>style.</em></h1>
            <p className="editorial-copy">
              Thoughtful pieces, easy layers, and a wardrobe that feels like you.
            </p>
            <div className="editorial-mark" aria-hidden="true"><span>SH</span></div>
          </div>
          <section className="auth-card" aria-labelledby="auth-title">
            <p className="eyebrow">{mode === 'login' ? 'WELCOME BACK' : 'YOUR STYLE STARTS HERE'}</p>
            <h2 id="auth-title">{mode === 'login' ? 'Sign in' : 'Create your account'}</h2>
            <p className="form-intro">
              {mode === 'login'
                ? 'Sign in to pick up right where you left off.'
                : 'Join us for a more personal way to shop.'}
            </p>
            <div className="mode-switch" aria-label="Account access">
              <button
                aria-pressed={mode === 'login'}
                className={mode === 'login' ? 'active' : ''}
                onClick={() => { setMode('login'); setError('') }}
                type="button"
              >Sign in</button>
              <button
                aria-pressed={mode === 'register'}
                className={mode === 'register' ? 'active' : ''}
                onClick={() => { setMode('register'); setError('') }}
                type="button"
              >Create account</button>
            </div>
            <form onSubmit={handleSubmit}>
              <label htmlFor="email">Email address</label>
              <input
                autoComplete="email"
                id="email"
                onChange={(event) => setEmail(event.target.value)}
                placeholder="you@example.com"
                required
                type="email"
                value={email}
              />
              <label htmlFor="password">Password</label>
              <input
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                id="password"
                minLength={8}
                onChange={(event) => setPassword(event.target.value)}
                placeholder="At least 8 characters"
                required
                type="password"
                value={password}
              />
              {error && <p className="error-message" role="alert">{error}</p>}
              <button className="submit-button" disabled={isLoading} type="submit">
                {isLoading
                  ? 'One moment…'
                  : mode === 'login'
                    ? 'Sign in to StyleHub'
                    : 'Create my account'}
                {!isLoading && <span aria-hidden="true">↗</span>}
              </button>
            </form>
            <p className="form-footnote">A considered wardrobe begins with you.</p>
          </section>
        </section>
        <footer className="footer">
          <span>R&amp;R STYLEHUB · MADE FOR YOUR EVERYDAY</span>
          <span>DAY 1 · ACCOUNT ACCESS</span>
        </footer>
      </main>
    )
  }

  const cartCount = cart?.items.reduce((total, item) => total + item.quantity, 0) ?? 0

  return (
    <main className="page-shell store-shell">
      <header className="topbar store-topbar">
        <button className="wordmark wordmark-button" onClick={() => setView('shop')} type="button">
          R&amp;R stylehub
        </button>
        <nav className="store-nav" aria-label="Store navigation">
          <button className={view === 'shop' ? 'selected' : ''} onClick={() => setView('shop')} type="button">Shop</button>
          <button className={view === 'cart' || view === 'checkout' ? 'selected' : ''} onClick={() => setView('cart')} type="button">
            Bag <span className="nav-count">{cartCount}</span>
          </button>
          <button className={view === 'orders' ? 'selected' : ''} onClick={() => setView('orders')} type="button">Orders</button>
          <button className="text-button" onClick={signOut} type="button">Sign out</button>
        </nav>
      </header>

      <section className="store-content">
        {notice && <p className="notice-message" role="status">{notice}</p>}
        {error && (
          <div className="error-banner" role="alert">
            <span>{error}</span>
            <button aria-label="Dismiss error" onClick={() => setError('')} type="button">×</button>
          </div>
        )}

        {view === 'shop' && (
          <>
            <div className="shop-heading">
              <div>
                <p className="eyebrow">A THOUGHTFUL WARDROBE</p>
                <h1>Made for your<br /><em>everyday.</em></h1>
              </div>
              <p className="shop-description">Easy layers and considered essentials<br />to make getting dressed feel simple.</p>
            </div>
            <div className="product-grid">
              {products.map((product, index) => (
                <article className="product-card" key={product.id}>
                  <div className="product-image-wrap">
                    <img alt={product.name} className="product-image" loading="lazy" src={product.image_url} />
                    <span className="product-number">0{index + 1}</span>
                  </div>
                  <div className="product-meta">
                    <span>{product.category}</span>
                    <span>{formatPrice(product.price_minor_units)}</span>
                  </div>
                  <h2>{product.name}</h2>
                  <p>{product.description}</p>
                  <button className="add-button" onClick={() => addToCart(product.id)} type="button">
                    Add to bag <span aria-hidden="true">+</span>
                  </button>
                </article>
              ))}
            </div>
          </>
        )}

        {view === 'cart' && (
          <section className="bag-view">
            <div className="section-heading">
              <p className="eyebrow">YOUR EDIT</p>
              <h1>Your bag<span>.</span></h1>
              <p>{cartCount} {cartCount === 1 ? 'piece' : 'pieces'} selected with you in mind.</p>
            </div>
            {!cart?.items.length ? (
              <div className="empty-state">
                <p>Your bag is waiting for something lovely.</p>
                <button className="submit-button" onClick={() => setView('shop')} type="button">Explore the collection <span>↗</span></button>
              </div>
            ) : (
              <div className="bag-layout">
                <div className="bag-lines">
                  {cart.items.map((item) => (
                    <article className="bag-line" key={item.product_id}>
                      <img alt={item.name} src={item.image_url} />
                      <div className="bag-line-copy">
                        <h2>{item.name}</h2>
                        <p>{formatPrice(item.price_minor_units, cart.currency)}</p>
                        <div className="quantity-control" aria-label={`Quantity for ${item.name}`}>
                          <button aria-label="Decrease quantity" disabled={item.quantity <= 1} onClick={() => updateQuantity(item.product_id, item.quantity - 1)} type="button">−</button>
                          <span>{item.quantity}</span>
                          <button aria-label="Increase quantity" disabled={item.quantity >= 20} onClick={() => updateQuantity(item.product_id, item.quantity + 1)} type="button">+</button>
                          <button className="remove-button" onClick={() => removeFromCart(item.product_id)} type="button">Remove</button>
                        </div>
                      </div>
                      <strong>{formatPrice(item.line_total_minor_units, cart.currency)}</strong>
                    </article>
                  ))}
                </div>
                <form
                  className="order-summary"
                  onSubmit={(event) => {
                    event.preventDefault()
                    void beginCheckout()
                  }}
                >
                  <p className="eyebrow">ORDER SUMMARY</p>
                  <div><span>Subtotal</span><strong>{formatPrice(cart.total_minor_units, cart.currency)}</strong></div>
                  <div><span>Shipping</span><span>No shipping fee</span></div>
                  <div className="summary-total"><span>Total</span><strong>{formatPrice(cart.total_minor_units, cart.currency)}</strong></div>
                  <fieldset className="delivery-details">
                    <legend>Delivery address and contact</legend>
                    <label htmlFor="shipping-name">Full name</label>
                    <input
                      autoComplete="name"
                      id="shipping-name"
                      maxLength={120}
                      onChange={(event) => setShippingAddress({ ...shippingAddress, full_name: event.target.value })}
                      required
                      value={shippingAddress.full_name}
                    />
                    <label htmlFor="shipping-phone">Phone number</label>
                    <input
                      autoComplete="tel"
                      id="shipping-phone"
                      maxLength={20}
                      minLength={7}
                      onChange={(event) => setShippingAddress({ ...shippingAddress, phone: event.target.value })}
                      pattern="[\d\s()+.-]{7,20}"
                      required
                      type="tel"
                      value={shippingAddress.phone}
                    />
                    <label htmlFor="shipping-address1">Address</label>
                    <input
                      autoComplete="address-line1"
                      id="shipping-address1"
                      maxLength={200}
                      onChange={(event) => setShippingAddress({ ...shippingAddress, address_line1: event.target.value })}
                      required
                      value={shippingAddress.address_line1}
                    />
                    <label htmlFor="shipping-address2">Apartment, suite, landmark (optional)</label>
                    <input
                      autoComplete="address-line2"
                      id="shipping-address2"
                      maxLength={200}
                      onChange={(event) => setShippingAddress({ ...shippingAddress, address_line2: event.target.value })}
                      value={shippingAddress.address_line2}
                    />
                    <div className="delivery-address-grid">
                      <div>
                        <label htmlFor="shipping-city">City</label>
                        <input
                          autoComplete="address-level2"
                          id="shipping-city"
                          maxLength={100}
                          onChange={(event) => setShippingAddress({ ...shippingAddress, city: event.target.value })}
                          required
                          value={shippingAddress.city}
                        />
                      </div>
                      <div>
                        <label htmlFor="shipping-state">State</label>
                        <input
                          autoComplete="address-level1"
                          id="shipping-state"
                          maxLength={100}
                          onChange={(event) => setShippingAddress({ ...shippingAddress, state: event.target.value })}
                          required
                          value={shippingAddress.state}
                        />
                      </div>
                    </div>
                    <label htmlFor="shipping-postal">PIN / postal code</label>
                    <input
                      autoComplete="postal-code"
                      id="shipping-postal"
                      maxLength={12}
                      minLength={3}
                      onChange={(event) => setShippingAddress({ ...shippingAddress, postal_code: event.target.value })}
                      required
                      value={shippingAddress.postal_code}
                    />
                  </fieldset>
                  <fieldset className="payment-methods">
                    <legend>Choose how to pay</legend>
                    {([
                      ['cash_on_delivery', 'Cash on delivery', 'Pay when your order arrives'],
                      ['upi', 'UPI', 'Pay securely with UPI'],
                      ['debit_card', 'Debit card', 'Pay securely by debit card'],
                      ['credit_card', 'Credit card', 'Pay securely by credit card'],
                    ] as const).map(([method, label, detail]) => (
                      <label className="payment-option" key={method}>
                        <input
                          checked={paymentMethod === method}
                          name="payment-method"
                          onChange={() => setPaymentMethod(method)}
                          type="radio"
                          value={method}
                        />
                        <span><strong>{label}</strong><small>{detail}</small></span>
                      </label>
                    ))}
                  </fieldset>
                  <button className="submit-button" disabled={isLoading} type="submit">
                    {isLoading
                      ? 'Preparing checkout…'
                      : paymentMethod === 'cash_on_delivery'
                        ? 'Place order'
                        : 'Continue to payment'} <span>↗</span>
                  </button>
                  <p className="payment-note">
                    {paymentMethod === 'cash_on_delivery'
                      ? 'No payment is collected until delivery.'
                      : 'Secure test-mode payment powered by Stripe.'}
                  </p>
                </form>
              </div>
            )}
          </section>
        )}

        {view === 'checkout' && checkout && (
          <section className="checkout-view">
            <div className="section-heading">
              <p className="eyebrow">ALMOST YOURS</p>
              <h1>Secure checkout<span>.</span></h1>
              <p>Complete your {checkout.order.payment_method === 'upi' ? 'UPI' : 'card'} payment to place order #{checkout.order.id}.</p>
            </div>
            <div className="checkout-card">
              <div className="checkout-total">
                <span>Order total</span>
                <strong>{formatPrice(checkout.order.amount_minor_units, checkout.order.currency)}</strong>
              </div>
              <CheckoutPanel
                clientSecret={checkout.client_secret}
                onCancel={() => setView('cart')}
                onComplete={finishCheckout}
                publishableKey={checkout.publishable_key}
              />
            </div>
          </section>
        )}

        {view === 'orders' && (
          <section className="orders-view">
            <div className="section-heading">
              <p className="eyebrow">THE PIECES YOU PICKED</p>
              <h1>Your orders<span>.</span></h1>
              <p>A little history of what is making its way to you.</p>
            </div>
            {!orders.length ? (
              <div className="empty-state">
                <p>No orders yet. Your next favourite might be right here.</p>
                <button className="submit-button" onClick={() => setView('shop')} type="button">Explore the collection <span>↗</span></button>
              </div>
            ) : (
              <div className="order-list">
                {orders.map((order) => (
                  <article className="order-card" key={order.id}>
                    <div className="order-card-heading">
                      <div>
                        <span>ORDER #{order.id}</span>
                        <time>{new Date(order.created_at).toLocaleDateString()}</time>
                        <span className="order-payment-method">
                          {order.payment_method === 'cash_on_delivery'
                            ? 'Cash on delivery'
                            : order.payment_method === 'upi'
                              ? 'UPI'
                              : order.payment_method === 'debit_card'
                                ? 'Debit card'
                                : 'Credit card'}
                        </span>
                      </div>
                      <span className={`status-pill status-${order.status}`}>{order.status}</span>
                    </div>
                    <div className="order-items">
                      {order.items.map((item) => (
                        <div className="order-item" key={item.product_id}>
                          <img alt="" src={item.image_url} />
                          <span>{item.name} <small>× {item.quantity}</small></span>
                          <strong>{formatPrice(item.line_total_minor_units, order.currency)}</strong>
                        </div>
                      ))}
                    </div>
                    {order.shipping_address && (
                      <div className="order-delivery-address">
                        <strong>Deliver to</strong>
                        <span>{order.shipping_address.full_name} · {order.shipping_address.phone}</span>
                        <span>
                          {order.shipping_address.address_line1}
                          {order.shipping_address.address_line2 && `, ${order.shipping_address.address_line2}`}
                          {`, ${order.shipping_address.city}, ${order.shipping_address.state} ${order.shipping_address.postal_code}`}
                        </span>
                      </div>
                    )}
                    <div className="order-total"><span>Total</span><strong>{formatPrice(order.amount_minor_units, order.currency)}</strong></div>
                  </article>
                ))}
              </div>
            )}
          </section>
        )}
      </section>

      <footer className="footer">
        <span>R&amp;R STYLEHUB · MADE FOR YOUR EVERYDAY</span>
        <span>WELCOME, {user.email.toUpperCase()}</span>
      </footer>
    </main>
  )
}

export default App
