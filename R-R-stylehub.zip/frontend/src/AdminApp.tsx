import { useEffect, useState, type FormEvent } from 'react'
import {
  apiRequest,
  formatPrice,
  type AdminProductInput,
  type Product,
} from './api'
import './App.css'

type TokenResponse = {
  access_token: string
}

type ProductForm = {
  name: string
  description: string
  category: string
  price: string
  stock_quantity: string
  image_url: string
}

const emptyForm: ProductForm = {
  name: '',
  description: '',
  category: '',
  price: '',
  stock_quantity: '0',
  image_url: '',
}

function productToForm(product: Product): ProductForm {
  return {
    name: product.name,
    description: product.description,
    category: product.category,
    price: (product.price_minor_units / 100).toFixed(2),
    stock_quantity: String(product.stock_quantity),
    image_url: product.image_url,
  }
}

export default function AdminApp() {
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [token, setToken] = useState<string | null>(
    () => sessionStorage.getItem('stylehub-admin-token'),
  )
  const [products, setProducts] = useState<Product[]>([])
  const [form, setForm] = useState<ProductForm>(emptyForm)
  const [editingId, setEditingId] = useState<number | null>(null)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [isLoading, setIsLoading] = useState(false)

  async function loadProducts(accessToken: string) {
    const result = await apiRequest<Product[]>('/api/admin/products', accessToken)
    setProducts(result)
  }

  useEffect(() => {
    if (!token) return
    let active = true
    apiRequest<Product[]>('/api/admin/products', token)
      .then((result) => {
        if (active) setProducts(result)
      })
      .catch((requestError: unknown) => {
        if (!active) return
        sessionStorage.removeItem('stylehub-admin-token')
        setToken(null)
        setError(requestError instanceof Error ? requestError.message : 'Could not load products.')
      })
    return () => {
      active = false
    }
  }, [token])

  async function signIn(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setError('')
    setIsLoading(true)
    try {
      const result = await apiRequest<TokenResponse>('/api/admin/login', undefined, {
        method: 'POST',
        body: JSON.stringify({ username, password }),
      })
      sessionStorage.setItem('stylehub-admin-token', result.access_token)
      setToken(result.access_token)
      setPassword('')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Admin sign-in failed.')
    } finally {
      setIsLoading(false)
    }
  }

  async function saveProduct(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!token) return
    setError('')
    setNotice('')
    setIsLoading(true)
    const product: AdminProductInput = {
      name: form.name.trim(),
      description: form.description.trim(),
      category: form.category.trim(),
      price_minor_units: Math.round(Number(form.price) * 100),
      stock_quantity: Number(form.stock_quantity),
      image_url: form.image_url.trim(),
    }
    try {
      await apiRequest<Product>(
        editingId === null ? '/api/admin/products' : `/api/admin/products/${editingId}`,
        token,
        {
          method: editingId === null ? 'POST' : 'PUT',
          body: JSON.stringify(product),
        },
      )
      await loadProducts(token)
      setEditingId(null)
      setForm(emptyForm)
      setNotice(editingId === null ? 'Product added to the customer catalog.' : 'Product updates saved.')
    } catch (requestError) {
      setError(requestError instanceof Error ? requestError.message : 'Product could not be saved.')
    } finally {
      setIsLoading(false)
    }
  }

  function signOut() {
    sessionStorage.removeItem('stylehub-admin-token')
    setToken(null)
    setProducts([])
    setForm(emptyForm)
    setEditingId(null)
    setNotice('')
  }

  return (
    <main className="page-shell admin-shell">
      <header className="topbar">
        <a className="wordmark" href="/">R&amp;R stylehub</a>
        <div className="admin-top-actions">
          <span className="topbar-note">Store administration</span>
          {token && <button className="text-button" onClick={signOut} type="button">Sign out</button>}
        </div>
      </header>

      <section className="admin-content">
        {error && <p className="error-banner" role="alert">{error}</p>}
        {notice && <p className="notice-message" role="status">{notice}</p>}
        {!token ? (
          <section className="auth-card admin-login" aria-labelledby="admin-title">
            <p className="eyebrow">RESTRICTED ACCESS</p>
            <h2 id="admin-title">Admin sign in</h2>
            <p className="form-intro">Sign in to manage products shown in the customer store.</p>
            <form onSubmit={signIn}>
              <label htmlFor="admin-username">Username</label>
              <input
                autoComplete="username"
                id="admin-username"
                onChange={(event) => setUsername(event.target.value)}
                required
                value={username}
              />
              <label htmlFor="admin-password">Password</label>
              <input
                autoComplete="current-password"
                id="admin-password"
                onChange={(event) => setPassword(event.target.value)}
                required
                type="password"
                value={password}
              />
              <button className="submit-button" disabled={isLoading} type="submit">
                {isLoading ? 'Signing in…' : 'Sign in to admin'} <span>↗</span>
              </button>
            </form>
          </section>
        ) : (
          <>
            <div className="section-heading">
              <p className="eyebrow">CATALOG MANAGEMENT</p>
              <h1>Manage products<span>.</span></h1>
              <p>Add products or update prices and stock for the customer website.</p>
            </div>
            <div className="admin-layout">
              <form className="admin-product-form" onSubmit={saveProduct}>
                <h2>{editingId === null ? 'Add a product' : 'Update product'}</h2>
                <label htmlFor="product-name">Product name</label>
                <input
                  id="product-name"
                  maxLength={120}
                  onChange={(event) => setForm({ ...form, name: event.target.value })}
                  required
                  value={form.name}
                />
                <label htmlFor="product-description">Description</label>
                <textarea
                  id="product-description"
                  onChange={(event) => setForm({ ...form, description: event.target.value })}
                  required
                  rows={3}
                  value={form.description}
                />
                <label htmlFor="product-category">Category</label>
                <input
                  id="product-category"
                  maxLength={60}
                  onChange={(event) => setForm({ ...form, category: event.target.value })}
                  required
                  value={form.category}
                />
                <div className="admin-number-fields">
                  <div>
                    <label htmlFor="product-price">Price (INR)</label>
                    <input
                      id="product-price"
                      min="0.01"
                      onChange={(event) => setForm({ ...form, price: event.target.value })}
                      required
                      step="0.01"
                      type="number"
                      value={form.price}
                    />
                  </div>
                  <div>
                    <label htmlFor="product-quantity">Quantity in stock</label>
                    <input
                      id="product-quantity"
                      max="5000"
                      min="0"
                      onChange={(event) => setForm({ ...form, stock_quantity: event.target.value })}
                      required
                      type="number"
                      value={form.stock_quantity}
                    />
                  </div>
                </div>
                <label htmlFor="product-image">Image URL</label>
                <input
                  id="product-image"
                  onChange={(event) => setForm({ ...form, image_url: event.target.value })}
                  required
                  type="url"
                  value={form.image_url}
                />
                <div className="admin-form-actions">
                  <button className="submit-button" disabled={isLoading} type="submit">
                    {isLoading ? 'Saving…' : editingId === null ? 'Add product' : 'Save changes'}
                  </button>
                  {editingId !== null && (
                    <button
                      className="text-button"
                      onClick={() => { setEditingId(null); setForm(emptyForm) }}
                      type="button"
                    >Cancel</button>
                  )}
                </div>
              </form>
              <section className="admin-product-list" aria-label="Existing products">
                {products.map((product) => (
                  <article className="admin-product-row" key={product.id}>
                    <img alt="" src={product.image_url} />
                    <div>
                      <h3>{product.name}</h3>
                      <p>{product.category} · {formatPrice(product.price_minor_units)} · {product.stock_quantity} in stock</p>
                    </div>
                    <button
                      className="admin-edit-button"
                      onClick={() => {
                        setEditingId(product.id)
                        setForm(productToForm(product))
                        setNotice('')
                      }}
                      type="button"
                    >Edit</button>
                  </article>
                ))}
              </section>
            </div>
          </>
        )}
      </section>
      <footer className="footer">
        <span>R&amp;R STYLEHUB · STORE ADMIN</span>
        <span><a href="/">RETURN TO SHOP</a></span>
      </footer>
    </main>
  )
}
