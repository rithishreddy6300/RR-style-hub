import { useMemo, useState, type FormEvent } from 'react'
import { Elements, PaymentElement, useElements, useStripe } from '@stripe/react-stripe-js'
import { loadStripe } from '@stripe/stripe-js'

type CheckoutPanelProps = {
  clientSecret: string
  publishableKey: string
  onComplete: () => Promise<void>
  onCancel: () => void
}

function PaymentForm({
  onComplete,
  onCancel,
}: Omit<CheckoutPanelProps, 'clientSecret' | 'publishableKey'>) {
  const stripe = useStripe()
  const elements = useElements()
  const [error, setError] = useState('')
  const [isSubmitting, setIsSubmitting] = useState(false)

  async function submitPayment(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!stripe || !elements) return

    setError('')
    setIsSubmitting(true)
    try {
      const result = await stripe.confirmPayment({
        elements,
        confirmParams: { return_url: `${window.location.origin}/?payment=complete` },
        redirect: 'if_required',
      })
      if (result.error) {
        setError(result.error.message ?? 'Your payment could not be completed.')
        return
      }
      if (result.paymentIntent?.status === 'succeeded') {
        await onComplete()
      } else if (result.paymentIntent?.status === 'processing') {
        await onComplete()
      } else {
        setError('The payment has not completed. Please try again.')
      }
    } catch (paymentError) {
      setError(
        paymentError instanceof Error
          ? paymentError.message
          : 'Your payment could not be completed.',
      )
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <form className="payment-form" onSubmit={submitPayment}>
      <PaymentElement />
      {error && <p className="error-message" role="alert">{error}</p>}
      <button className="submit-button" disabled={!stripe || isSubmitting} type="submit">
        {isSubmitting ? 'Confirming payment…' : 'Pay securely'}
      </button>
      <button className="text-button payment-cancel" onClick={onCancel} type="button">
        Return to cart
      </button>
      <p className="payment-note">Secure test-mode payment powered by Stripe.</p>
    </form>
  )
}

export default function CheckoutPanel(props: CheckoutPanelProps) {
  const stripePromise = useMemo(() => loadStripe(props.publishableKey), [props.publishableKey])
  return (
    <Elements
      options={{ clientSecret: props.clientSecret, appearance: { theme: 'stripe' } }}
      stripe={stripePromise}
    >
      <PaymentForm onCancel={props.onCancel} onComplete={props.onComplete} />
    </Elements>
  )
}
